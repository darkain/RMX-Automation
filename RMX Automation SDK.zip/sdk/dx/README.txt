This entire section of the SDK is very old, and is labeled
as DEPRICATED. All "Win32" specific code is being replaced
by a web based front-end in RMX version 2.0