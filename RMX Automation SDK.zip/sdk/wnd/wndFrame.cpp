/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#if 0

#include "wndFrame.h"


wndFrame::wndFrame(wndBase *parent) : wndBase("wndFrame", parent) {
}


wndFrame::~wndFrame() {
}

#endif
