/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#include "rmxBase.h"
#include "rmxUnicode.h"
#include "Win32/Win32.h"


rmxUtf8ToWide::rmxUtf8ToWide(const char *string, int length) {
  buffer = NULL;
  if (string) {
#ifdef _WIN32
    len = MultiByteToWideChar(CP_UTF8, 0, string, length, 0, 0);
    buffer = (wchar_t*) malloc(len * 2);
    MultiByteToWideChar(CP_UTF8, 0, string, length, (LPWSTR)buffer, len);
#else
#   error PORT ME
#endif
  }
}

rmxUtf8ToWide::~rmxUtf8ToWide() {
  if (buffer) free(buffer);
}


//-------------------------------------------------------------


rmxWideToUtf8::rmxWideToUtf8(const wchar_t *string, int length) {
  buffer = NULL;
  if (string) {
#ifdef _WIN32
    len = WideCharToMultiByte(CP_UTF8, 0, string, length, 0, 0, NULL, NULL);
    buffer = (char*) malloc(len);
    WideCharToMultiByte(CP_UTF8, 0, string, length, (char*)buffer, len, NULL, NULL);
#else
#   error PORT ME
#endif
  }
}

rmxWideToUtf8::~rmxWideToUtf8() {
  if (buffer) free(buffer);
}
