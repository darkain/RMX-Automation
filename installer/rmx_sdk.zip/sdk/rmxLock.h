/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#ifndef _RMX_LOCK_H_
#define _RMX_LOCK_H_


#include "rmxTypes.h"


class rmxLock {
  public:
    rmxLock(BOOL locked=FALSE) { setLocked(locked); }
    ~rmxLock() {}

  public:
    inline void lock()   { slock = TRUE;  }
    inline void unlock() { slock = FALSE; }
    inline BOOL isLocked()   const { return  slock; }
    inline BOOL isUnlocked() const { return !slock; }
    inline void setLocked(BOOL locked) { slock = !!locked; }

  private:
    BOOL slock;
};


#endif //_RMX_LOCK_H_
