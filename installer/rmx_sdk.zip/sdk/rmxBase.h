/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#ifndef _RMX_BASE_H_
#define _RMX_BASE_H_


#include "../predefine.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rmxTypes.h"
#include "rmxUnicode.h"


#include "handles/hplugin.h"
#include "handles/hconsole.h"
#include "handles/hfunction.h"


#ifdef __cplusplus
extern "C" {
#endif


#ifndef CHAT
#define CHAT(from, to, text) message(__FILE__ "(" WARNING_TOSTR1(__LINE__) ") : <" from "> " to ": " text)
#define SELF(from, text) message(__FILE__ "(" WARNING_TOSTR1(__LINE__) ") : * " from"/#vbase " text)
#endif //CHAT


#define VSTRCMP  strcmp
#define VSTRLEN  strlen
#define WSTRLEN  wcslen
char *VSTRDUP(const char *string);
BOOL VFEXISTS(const char *path);
VINT VFSIZE(  const char *path);


#if defined (_MSC_VER) && (_MSC_VER >= 1400)
#define VPRINTF sprintf_s
#define VSCANF  sscanf_s
#define VSTRCMPI _strcmpi
#define VSTRCPY(dst, src, len) strncpy_s(dst, len, src, VSTRLEN(src))
#define VSTRCAT(dst, src, len) strncat_s(dst, len, src, VSTRLEN(src))
#define WPRINTF swprintf_s
#define WSTRCPY(dst, src, len) wcsncpy_s(dst, len, src, WSTRLEN(src))
#define WSTRCAT(dst, src, len) wcsrncat_s(dst, len, src, WSTRLEN(src))
#define VFOPEN(file, filename, mode) fopen_s(file, filename, mode)
int RAND();
#else
#define VPRINTF _snprintf
#define VSCANF   sscanf
#define VSTRCPY  strncpy
#define VSTRCMPI strcmpi
#define VSTRCAT  strncat
#define WPRINTF _snwprintf
#define WSTRCMP  wstrcmp
#define WSTRCMPI wstrcmpi
#define WSTRCPY  wcsncpy
#define WSTRCAT  wstrncat
int VFOPEN(FILE **file, const char *path, const char *open);
#define RAND rand
#endif


#define vdelnull(x) { delete x; x=NULL; }
#define vrelease(x) { if(x) x->Release(); x=NULL; } 
#define vrestore(x) { if(x) x->Restore(); }


#ifdef _WIN32
#  define RMXOS vWin32
#else
#  error PORT ME
#endif


//just about everything below this line is being replaced by a new API in the works

/*
//extern void IntBox(int a=0, int b=0, int c=0);
//extern void FloatBox(double a=0, double b=0, double c=0);
//extern void MsgBox(const char *text, const char *title="Message Box", UINT style=0);
extern void EraseFile( const char *path);  //does not delete file, just empties contents
extern bool VFEXISTS(const char *path);
extern int  FileSize(  const char *path);
extern char *stristr ( const char *str1, const char *str2);
extern UINT Rand(UINT n);
extern const char *RMXOS::getPath();
extern const char *GetFilename();
//extern int __fastcall UnicodeToAnsi(const wchar_t *pszW, char **ppszA);

extern int specialString(const char *string);
*/


#ifdef __cplusplus
}  //extern "C"
#endif


#endif //_RMX_BASE_H_
