/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#ifndef _TIMER_DELETE_H_
#define _TIMER_DELETE_H_


#include "Timer.h"


class timerDelete : public vTimedCallback {
  public:
    timerDelete() {}
    virtual ~timerDelete() {}

  public:
    void deleteThis() {
      addEvent(this);
    }

  protected:
    virtual void onEvent(void *event) {
      if (event==(void*)this) delete this;
    }
};


#endif //_TIMER_DELETE_H_
