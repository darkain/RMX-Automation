/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


//class to recieve callbacks/events from a cfgBase


#ifndef _CB_BASE_H_
#define _CB_BASE_H_


#include "../cfg/cfgBase.h"


class cbBase {
  friend class cfgBase;

  protected:
    cbBase(cfgBase *item=NULL);
    virtual ~cbBase();

  public:
    cfgBase *getConfig() const;
    void setConfig(cfgBase *item);


  public:

    //called when watched list is being deleted
    //default action is to delete this instance as well, as it will no longer be valid
    virtual void cb_onDelete() { delete this; }

    //called when setName() happens
    virtual void cb_onNameChange(const char *newname) {}

    //called when tooltip text is changed
    virtual void cb_onSetTooltip(const char *newtip) {}

    //called when user data is changed.  (such as string, int, etc value, or vSetting function string
    virtual void cb_onSetUserData(const prmBase *userdata) {}

    //called when a param is added to the watched list
    virtual void cb_onInsertParam(const prmBase *param, const prmBase *insert) {}

    //called when a param is removed from the watched list
    virtual void cb_onRemoveParam(const prmBase *param) {}

    //called when the posisition of a param with a list is changed
    virtual void cb_onMoveParam(const prmBase *param, const prmBase *insert) {}

    //called when a param is set to a new string
    virtual void cb_onSetParam(const prmBase *param) {}

    //called when a new child list is added to the watched list
    virtual void cb_onInsertChild(cfgBase *child, const cfgBase *insert) {}

    //called when a child list is removed from the watched list
    virtual void cb_onRemoveChild(const cfgBase *child) {}

    //called when a child is moved within the list to a new location
    virtual void cb_onMoveChild(const cfgBase *child, const cfgBase *insert) {}

    //called when specified list is hidden or shown
    virtual void cb_onSetVisible(BOOL isvisible) {}

    //called when specified list is enabled or disabled
    virtual void cb_onSetEnabled(BOOL isenable) {}

    //called when specified list is expanded or collapsed
    virtual void cb_onSetExpanded(BOOL isexpanded) {}

    //called when specified list is highlighted or returned to normal
    virtual void cb_onSetHighlighted(BOOL ishighlighted) {}

    //called when specified list savable to XML state changes
    virtual void cb_onSetSavable(BOOL savable) {}

    //called when specified list accessable to NetSlave state changes
    virtual void cb_onSetNetSlave(BOOL netslave) {}

    //called when specified list accessable to ICP state changes
    virtual void cb_onSetIpc(BOOL ipc) {}

    //called when specified list writability state changes
    virtual void cb_onSetReadOnly(BOOL readonly) {}

  private:
    cfgBase *config;
};


#endif //_CFG_CALLBACK_H_
