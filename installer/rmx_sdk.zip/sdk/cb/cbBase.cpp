/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#include "../rmxBase.h"
#include "cbBase.h"


cbBase::cbBase(cfgBase *item) {
  config = NULL;
  setConfig(item);
}


cbBase::~cbBase() {
  setConfig(NULL);
}


cfgBase *cbBase::getConfig() const {
  return config;
}


void cbBase::setConfig(cfgBase *item) {
  if (item == config) return;
  if (config) config->removeCallback(this);
  config = item;
  if (config) config->insertCallback(this);
}
