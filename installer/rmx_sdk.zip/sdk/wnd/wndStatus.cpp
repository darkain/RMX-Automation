/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#include "wndStatus.h"
#include <commctrl.h>


wndStatus::wndStatus(wndBase *parent) : wndSubclass(STATUSCLASSNAMEA, parent) {
  appendWindowStyle(SBARS_SIZEGRIP | SBARS_TOOLTIPS);
  setName("");
}


wndStatus::~wndStatus() {
}

void wndStatus::autoposition() {
  sendMessage(WM_SIZE);
}

void wndStatus::setStatusParts(int *array, int numparts) {
  sendMessage(SB_SETPARTS, numparts, (UINT)array);
}

void wndStatus::setStatusText(const char *text, int bar) {
  rmxUtf8ToWide str(text);
  sendMessage(SB_SETTEXT, bar, (UINT)str.getBuffer());
}

char *wndStatus::getStatusText(char *buffer, int bar) {
  //todo: UNICODE
  sendMessageA(SB_GETTEXTLENGTH, bar, (UINT)buffer);
  return buffer;
}

VINT wndStatus::getStatusTextLength(int bar) {
  return sendMessage(SB_GETTEXTLENGTH, bar);
}

void wndStatus::getStatusRect(RECT *r, int bar) {
  sendMessage(SB_GETRECT, bar, (UINT)r);
}
/*
UINT wndStatus::onCommand(USHORT id, USHORT cmd, LPARAM lParam) {
  wndBase *par = getvParent();
  if (par) return par->onCommand(id, cmd, lParam);
  return vSubclassWnd::onCommand(id, cmd, lParam);
}
*/


//----------------------------------------------------------------------------------------



vButtonStatusWnd::vButtonStatusWnd(wndBase *parent) : wndStatus(parent) {
}


vButtonStatusWnd::~vButtonStatusWnd() {
}


void vButtonStatusWnd::onResize(int width, int height) {
  wndStatus::onResize(width, height);
}
