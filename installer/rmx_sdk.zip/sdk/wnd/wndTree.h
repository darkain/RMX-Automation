/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#ifndef _WND_TREE_H_
#define _WND_TREE_H_


#include "wndBase.h"
#include "../whk/whkNotify.h"
#include <commctrl.h>


class wndTreeItem;
class wndTreeItemList;


class wndTree : public wndBase, public whkNotify {
  friend class wndTreeItem;

  public:
    wndTree(wndBase *parent=NULL);
    virtual ~wndTree();

  public:
    void clearList();

    void addTreeChild(wndTreeItem *item);
    void delTreeChild(wndTreeItem *item);

    inline wndTreeItem *getSelected() const { return selected; }
    inline wndTreeItem *getFirstItem() const { return items.getFirstItem(); }
    inline wndTreeItem *getNextItem(wndTreeItem *i) const { return items.getNextItem(i); }
    inline wndTreeItem *getPrevItem(wndTreeItem *i) const { return items.getPrevItem(i); }
    inline wndTreeItem *getLastItem() const { return items.getLastItem(); }

    inline UINT getItemCount() const { return items.getItemCount(); }
    inline BOOL hasItem(wndTreeItem *i) const { return items.hasItem(i); }

    wndTreeItem *addTreeItem(const char *name, UINT notifyId=0, wndTreeItem *parent=NULL, UINT param=0);
    void addTreeItem(wndTreeItem *treeItem);

  protected:
    virtual wndTreeItem *newTreeItem(const char *name, wndTreeItem *parent, UINT param=0);
    virtual BOOL onNotify(whkInfo *info, NMHDR *notify);

  protected:
    rmxList<wndTreeItem*> items;
    wndTreeItem *selected;
};


//----------------------------------------------------------------------------------------------------


class wndTreeItem : public rmxName {
  friend class wndTree;

  public:
    wndTreeItem(const char *name, wndTreeItem *parent);
    virtual ~wndTreeItem();

    virtual void onInit() {}

    virtual void onDeselected();
    virtual void onSelected();

    void select();

    void addTreeChild(wndTreeItem *item);
    void delTreeChild(wndTreeItem *item);
    wndTreeItem *getFirstItem() { return items.getFirstItem(); }
    wndTreeItem *getNextItem(wndTreeItem *i) { return items.getNextItem(i); }
    wndTreeItem *getPrevItem(wndTreeItem *i) { return items.getPrevItem(i); }
    wndTreeItem *getLastItem() { return items.getLastItem(); }
    UINT getItemCount() { return items.getItemCount(); }

    wndTreeItem *getTreeParent() { return treeParent; }
    wndTreeItem *getTreeRoot() { return treeRoot; }

    void setWnd(HWND hWnd) { hTree = hWnd; }
    HWND getWnd() { return hTree; }
    void setWnd(wndTree *w);
    wndTree *getwndBase();

    void setTreeItem(HTREEITEM item) { hItem = item; }
    HTREEITEM getTreeItem() { return hItem; }

    void setExpanded(BOOL expand);
    BOOL isExpanded();
    virtual void onSetExpanded(BOOL expanded) {}

    //from class Name
    virtual void onNameChange(const char *newname);

  protected:
    rmxList<wndTreeItem*> items;
    wndTreeItem *treeParent;
    wndTreeItem *treeRoot;
    HTREEITEM hItem;
    HWND hTree;
    wndTree *wnd;
};


#endif //_WND_TREE_H_
