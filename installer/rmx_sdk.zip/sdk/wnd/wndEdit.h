/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#ifndef _WND_EDIT_H_
#define _WND_EDIT_H_


#include "wndSubclass.h"


class wndEdit : public wndSubclass {
  public:
//    wndEdit(HWND newWnd);
//    wndEdit(HWND newWnd, wndBase *parent);
    wndEdit(wndBase *parent);
    virtual ~wndEdit() {}

  protected:
    virtual LRESULT CALLBACK subWndProc(HWND hWndmsg, UINT uMsg, WPARAM wParam, LPARAM lParam);
};


#endif //_WND_EDIT_H_
