/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#include "wndTree.h"


wndTree::wndTree(wndBase *parent) : wndBase("SysTreeView32", parent) {
  appendWindowStyleEx(WS_EX_CLIENTEDGE);
  selected = NULL;
  insertHookWnd(parent);
}


wndTree::~wndTree() {
  clearList();
}


void wndTree::clearList() {
  wndTreeItem *itm = items.getFirstItem();
  while (itm) {
    items.removeItem(itm);
    delete itm;
    itm = items.getFirstItem();
  }
  TreeView_DeleteAllItems(getWnd());
}


wndTreeItem *wndTree::newTreeItem(const char *name, wndTreeItem *parent, UINT param) {
  return new wndTreeItem(name, parent);
}


void wndTree::addTreeChild(wndTreeItem *item) {
  items.appendItem(item);
}

void wndTree::delTreeChild(wndTreeItem *item) {
  items.removeItem(item);
}


wndTreeItem *wndTree::addTreeItem(const char *name, UINT notifyId, wndTreeItem *parent, UINT param) {
  wndTreeItem *treeItem = newTreeItem(name, parent, param);
  if (treeItem == NULL) return NULL;

  addTreeItem(treeItem);
  return treeItem;
}


void wndTree::addTreeItem(wndTreeItem *treeItem) {
  treeItem->setWnd(this);

  rmxUtf8ToWide str(treeItem->getName());
  
  TVINSERTSTRUCTW a;
  if (treeItem->getTreeParent()) a.hParent = treeItem->getTreeParent()->getTreeItem();
  else a.hParent  = NULL;
  a.hInsertAfter  = TVI_LAST;
  a.item.mask     = TVIF_TEXT | TVIF_PARAM;
  a.item.pszText  = (LPWSTR)str.getBuffer();
  a.item.lParam   = (LPARAM)treeItem;

  HTREEITEM hItem = (HTREEITEM)sendMessage(TVM_INSERTITEMW, NULL, (LPARAM)&a);
  treeItem->setTreeItem(hItem);

  items.appendItem(treeItem);
}


BOOL wndTree::onNotify(whkInfo *info, NMHDR *notify) {
  NMTREEVIEW *tree_notify = (NMTREEVIEW*) notify;

  if (info->param1 == getId()) {
    if (notify->code == TVN_SELCHANGED) {
      wndTreeItem *prewndTreeItem = (wndTreeItem*)tree_notify->itemOld.lParam;
      if (prewndTreeItem  &&  items.hasItem(prewndTreeItem)) {
        prewndTreeItem->onDeselected();
      }

      wndTreeItem *nextTreeItem = (wndTreeItem*)tree_notify->itemNew.lParam;
      if (nextTreeItem  &&  items.hasItem(nextTreeItem)) {
        nextTreeItem->onSelected();
      }

      setFocus();
    }

    else if (notify->code == TVN_ITEMEXPANDED) {
      wndTreeItem *item = (wndTreeItem*)tree_notify->itemNew.lParam;
      if (item  &&  items.hasItem(item)) {
        item->onSetExpanded(item->isExpanded());
      }
    }
  }
  return FALSE;
}


//----------------------------------------------------------------------------------------------


wndTreeItem::wndTreeItem(const char *name, wndTreeItem *parent) : rmxName(name) {
  treeParent = parent;
  treeRoot = NULL;
  hTree = NULL;

  if (treeParent) {
    treeRoot = treeParent->getTreeRoot();
    treeParent->addTreeChild(this);
  }
  else {
    treeRoot = this;
  }
}


wndTreeItem::~wndTreeItem() {
  wndTreeItem *itm = items.getFirstItem();
  while (itm) {
    items.removeItem(itm);
    delete itm;
    itm = items.getFirstItem();
  }

  if (treeParent)  treeParent->delTreeChild(this);
  if (wnd) {
    if (wnd->selected == this) wnd->selected = NULL;
    wnd->delTreeChild(this);
  }
  TreeView_DeleteItem(hTree, hItem);
}


void wndTreeItem::select() {
  TreeView_SelectItem(hTree, hItem);
}


void wndTreeItem::setExpanded(BOOL expand) {
  TreeView_Expand( hTree, hItem, (expand?TVE_EXPAND:TVE_COLLAPSE) );
  onSetExpanded(expand);
}


BOOL wndTreeItem::isExpanded() {
  TVITEM tvitem;
  ZeroMemory(&tvitem, sizeof(TVITEM));
  tvitem.mask = TVIF_STATE;
  tvitem.stateMask = TVIS_EXPANDED;
  tvitem.hItem = hItem;
  TreeView_GetItem(hTree, &tvitem);
  return (tvitem.state & TVIS_EXPANDED) > 0;
}


void wndTreeItem::setWnd(wndTree *w) {
  wnd = w;
  if (wnd) {
    hTree = w->getWnd();
  } else {
    hTree = NULL;
  }
}


wndTree *wndTreeItem::getwndBase() {
  return wnd;
}


void wndTreeItem::addTreeChild(wndTreeItem *item) {
  items.appendItem(item);

}

void wndTreeItem::delTreeChild(wndTreeItem *item) {
  items.removeItem(item);
}

void wndTreeItem::onDeselected() {
  wnd->selected = NULL;
}

void wndTreeItem::onSelected() {
  wnd->selected = this;
}

void wndTreeItem::onNameChange(const char *newname) {
  if (!hTree) return;
  if (!hItem) return;

  rmxUtf8ToWide str(getName(""));

  TVITEMW tvitem;
  ZeroMemory(&tvitem, sizeof(TVITEM));
  tvitem.mask    = TVIF_TEXT;
  tvitem.hItem   = hItem;
  tvitem.pszText = (LPWSTR)str.getBuffer();
  wnd->sendMessage(TVM_SETITEM, 0, (LPARAM)&tvitem);
}
