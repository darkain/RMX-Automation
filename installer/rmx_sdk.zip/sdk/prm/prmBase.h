/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#ifndef _PRM_BASE_H_
#define _PRM_BASE_H_


#include "../rmxTypes.h"
#include "../rmxName.h"
#include "../rmxGuid.h"


typedef enum {
  PDTNULL,         //NULL data
  PDTSHORTSTRING,  //string that uses local buffer
  PDTSTRING,       //string that mallocs a buffer
  PDTINT,          //32-bit integer
  PDTLONG,         //64-bit integer
  PDTNUMBER,       //64-bit float
  PDTGUID,         //128-bit GUID
  PDTFOURCC,       //32-bit four character code
} prmType;


class cfgBase;


class prmBase {
  friend class cfgBase;

  public:
    prmBase(const char *name=NULL);
    prmBase(const char *name, const char *value);
    prmBase(const char *name, int         value);
    prmBase(const char *name, RMXLONG     value);
    prmBase(const char *name, double      value);
    prmBase(const char *name, GUID        value);
    prmBase(const char *name, FOURCC      value);
    ~prmBase();

  public:
    inline const char *getName() const { return myname.getName(); }
    inline BOOL isNamed(const char *name) const { return (VSTRCMP(name, getName()) == 0); }

    const char   *getValue() const;
//    const wchar_t getValueWide() const;  //TODO: implement this
    int           getValueInt() const;
    RMXLONG       getValueLong() const;
    double        getValueNumber() const;
    GUID          getValueGuid() const;
    FOURCC        getValueFourCC() const;
    BOOL          isValued(const char *value) const;

    inline void setValueNull() { setValue((char*)NULL); }
    void setValue(const char *newvalue);
    void setValue(const wchar_t *newvalue);
    void setValueString(const char *newvalue, VINT len=-1);
    void setValueWide(const wchar_t *newvalue);
    void setValueInt(int newvalue);
    void setValueLong(RMXLONG newvalue);
    void setValueNumber(double newvalue);
    void setValueGuid(GUID newvalue);
    void setValueFourCC(FOURCC newval);

    inline prmType getType() const { return (prmType) flags.datatype; }

    inline BOOL isNull()     const { return (flags.datatype == PDTNULL  ); }
    inline BOOL isString()   const { return (flags.datatype == PDTSTRING  ||  flags.datatype == PDTSHORTSTRING); }
    inline BOOL isInteger()  const { return (flags.datatype == PDTINT   ); }
    inline BOOL isLong()     const { return (flags.datatype == PDTLONG  ); }
    inline BOOL isNumber()   const { return (flags.datatype == PDTNUMBER); }
    inline BOOL isGuid()     const { return (flags.datatype == PDTGUID  ); }
    inline BOOL isFourCC()   const { return (flags.datatype == PDTFOURCC); }
    
    inline BOOL isSavable()  const { return flags.savable;  }
    inline void setSavable(BOOL savable) { flags.savable = !!savable; }

    inline BOOL isReadOnly() const { return flags.readonly; }
    inline void setReadOnly(BOOL readonly) { flags.readonly = !!readonly; }

    inline UINT getFlags()   const { return flags.flags;    }
    inline unsigned char getSecurity()   const { return flags.security; }
    inline unsigned char getSecurityEx() const { return flags.external; }



    //this is for internal use by RMX, try not to mess with it
    inline void setSecurityEx(unsigned char ex) { flags.external = ex; }


  private:  //for now
    inline void setFlags(UINT flgs)            { flags.flags    = flgs; }
    inline void setSecurity(unsigned char sec) { flags.security = sec;  }

  private:
    void nulldata();

  public:
    static int prmBase::specialString(const char *string);


  private:
    typedef union {
      UINT flags;
      struct {
        unsigned datatype      : 8;
        unsigned reserved1     :16;
        unsigned savable       : 1;
        unsigned ipc           : 1;
        unsigned netslave      : 1;
        unsigned readonly      : 1;
        unsigned external      : 4;
      };
      struct {
        unsigned char reserved_security[3];
        unsigned char security;
      };
    } FLAGS;


    typedef union {
      int      integer;
      char    *string1;
      char     string2[16];
      double   number;
      RMXLONG  longint;
      GUID     guid;
      FOURCC   fourcc;
    } VALUE;


  private:
    FLAGS flags;
    VALUE value;
    rmxName myname;

  private:
    static char buffer[64];
};


#endif //_PRM_BASE_H_
