/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#include "../rmxBase.h"
#include "../win32/win32.h"
#include "prmBase.h"


char prmBase::buffer[64] = "";


prmBase::prmBase(const char *name) : myname(name) {
  flags.flags = 0;
  nulldata();
}


prmBase::prmBase(const char *name, const char *value) : myname(name) {
  flags.flags = 0;
  nulldata();
  setValue(value);
}


prmBase::prmBase(const char *name, int value) : myname(name) {
  flags.flags = 0;
  nulldata();
  setValueInt(value);
}


prmBase::prmBase(const char *name, RMXLONG value) : myname(name) {
  flags.flags = 0;
  nulldata();
  setValueLong(value);
}


prmBase::prmBase(const char *name, double value) : myname(name) {
  flags.flags = 0;
  nulldata();
  setValueNumber(value);
}


prmBase::prmBase(const char *name, GUID value) : myname(name) {
  flags.flags = 0;
  nulldata();
  setValueGuid(value);
}


prmBase::prmBase(const char *name, FOURCC value) : myname(name) {
  flags.flags = 0;
  nulldata();
  setValueFourCC(value);
}


prmBase::~prmBase() {
  nulldata();
}


const char *prmBase::getValue() const {
  switch (flags.datatype) {
    case PDTNULL:        return NULL;
    case PDTSHORTSTRING: return value.string2;
    case PDTFOURCC:      return value.string2;  //when setting value as 4CC, we NULL the 5th character
    case PDTSTRING:      return value.string1;

    case PDTINT:
      VPRINTF(buffer, sizeof(buffer), "%d", value.integer);
      return buffer;

    case PDTLONG:
      VPRINTF(buffer, sizeof(buffer), "%I64d", value.longint);
      return buffer;

    case PDTNUMBER:
      VPRINTF(buffer, sizeof(buffer), "%f", value.number);
      return buffer;

    case PDTGUID: return rmxGuid::guidToChar(value.guid, buffer);
  }
  return NULL;
}


int prmBase::getValueInt() const {
  switch (flags.datatype) {
    case PDTNULL:   return 0;
    case PDTINT:    return value.integer;
    case PDTFOURCC: return value.integer;
    case PDTLONG:   return static_cast<int>(value.longint);
    case PDTNUMBER: return static_cast<int>(value.number);

    case PDTSHORTSTRING: {
      int ret = 0;
      VSCANF(value.string2, "%d", &ret);
      return ret;
    }

    case PDTSTRING: {
      int ret = 0;
      if (value.string1) VSCANF(value.string1, "%d", &ret);
      return ret;
    }
  }
  return 0;
}


RMXLONG prmBase::getValueLong() const {
  switch (flags.datatype) {
    case PDTNULL:   return 0;
    case PDTLONG:   return value.longint;
    case PDTINT:    return value.integer;
    case PDTFOURCC: return value.integer;
    case PDTNUMBER: return static_cast<RMXLONG>(value.number);

    case PDTSHORTSTRING: {
      RMXLONG ret = 0;
      VSCANF(value.string2, "%I64d", &ret);
      return ret;
    }

    case PDTSTRING: {
      RMXLONG ret = 0;
      if (value.string1) VSCANF(value.string1, "%I64d", &ret);
      return ret;
    }
  }
  return 0;
}


double prmBase::getValueNumber() const {
  switch (flags.datatype) {
    case PDTNULL:   return 0;
    case PDTNUMBER: return value.number;
    case PDTINT:    return static_cast<double>(value.integer);
    case PDTFOURCC: return static_cast<double>(value.integer);
    case PDTLONG:   return static_cast<double>(value.longint);

    case PDTSHORTSTRING: {
      char *extra = NULL;
      return strtod(value.string2, &extra);
    }

    case PDTSTRING: {
      char *extra = NULL;
      return strtod(value.string1, &extra);
    }
  }
  return 0;
}


GUID prmBase::getValueGuid() const {
  if (flags.datatype == PDTGUID) return value.guid;
  return _INVALID_GUID;
}


FOURCC prmBase::getValueFourCC() const {
  switch (flags.datatype) {
    case PDTNULL:   return 0;
    case PDTINT:    return value.fourcc;
    case PDTFOURCC: return value.fourcc;
    case PDTLONG:   return static_cast<FOURCC>(value.longint);
    case PDTNUMBER: return static_cast<FOURCC>(value.number);
    case PDTSHORTSTRING: return value.fourcc;

    case PDTSTRING: {
      FOURCC ret = 0;
      if (value.string1) VSCANF(value.string1, "%4c", &ret);
      return ret;
    }
  }
  return 0;
}


BOOL prmBase::isValued(const char *value) const {
  const char *v = getValue();
  if (value == NULL  &&  v == NULL) return TRUE;
  if (value == NULL  ||  v == NULL) return FALSE;
  return (VSTRCMP(value, v) == 0);
}


void prmBase::setValue(const char *newvalue) {
  if (isReadOnly()) return;

  if (!newvalue) {
    nulldata();
    return;
  }


  VINT len = VSTRLEN(newvalue);


  if (len < 1) {
    nulldata();
    flags.datatype = PDTSHORTSTRING;
    return;
  }


  while (*newvalue) {
    if ( *newvalue ==  ' '  ||  *newvalue == '\r'
      || *newvalue == '\n'  ||  *newvalue == '\t' ) {
      len--;
      newvalue++;
    } else {
      break;
    }
  }

  if (*newvalue == NULL) {
    nulldata();
    flags.datatype = PDTSHORTSTRING;
    return;
  }

  if ( (len == 38) && (rmxGuid::isValidGuidString(newvalue, len)) ) {
    setValueGuid(rmxGuid::guidFromChar(newvalue));
    return;
  }

  int special = specialString(newvalue);
  if (special == 0  ||  special == 1) {
    setValueInt(special);
    return;
  }


  if (*newvalue != '0') {

    char *extra = NULL;
    double numeric = strtod(newvalue, &extra);
    if (numeric != 0) {
      char *p = extra;
      bool ok = true;
      if (p) {
        while (*p) {
          if (*p == ' '  ||  *p == '\t'  ||  *p == '\r'  ||  *p == '\n') {
          } else {
            ok = false;
          }
          p++;
        }
      }

      if (ok) {
        RMXLONG lng = static_cast<RMXLONG>(numeric);
        if (static_cast<double>(lng) - numeric == 0) {
          if ( (lng <= ((RMXLONG)(long)MAXLONG))  &&  (lng >= ((RMXLONG)(long)MINLONG)) ) {
            setValueInt((int)lng);
          } else {
            setValueLong(lng);
          }
        } else {
          setValueNumber(numeric);
        }
        return;
      }
    }

  }

  setValueString(newvalue, len);
}


void prmBase::setValue(const wchar_t *newvalue) {
  rmxWideToUtf8 str(newvalue);
  setValue(str.getBuffer());
}


void prmBase::setValueString(const char *newvalue, VINT len) {
  if (isReadOnly()) return;

  if (!newvalue) {
    nulldata();
    return;
  }

  if (len == -1) len = VSTRLEN(newvalue);

  if (len < sizeof(value.string2)) {
    nulldata();
    memcpy(value.string2, newvalue, len);
    value.string2[len] = NULL;
    flags.datatype = PDTSHORTSTRING;
  }

  else if (flags.datatype == PDTSTRING) {
    value.string1 = (char*)realloc(value.string1, len+1);
    memcpy(value.string1, newvalue, len);
    value.string1[len] = NULL;
  }

  else {
    nulldata();
    value.string1 = (char*) malloc(len+1);
    memcpy(value.string1, newvalue, len);
    value.string1[len] = NULL;
    flags.datatype = PDTSTRING;
  }
}


void prmBase::setValueWide(const wchar_t *newvalue) {
  rmxWideToUtf8 str(newvalue);
  setValueString(str.getBuffer());
}


void prmBase::setValueInt(int newvalue) {
  if (isReadOnly()) return;

  nulldata();
  flags.datatype = PDTINT;
  value.integer  = newvalue;
}


void prmBase::setValueLong(RMXLONG newvalue) {
  if (isReadOnly()) return;

  nulldata();
  flags.datatype = PDTLONG;
  value.longint  = newvalue;
}


void prmBase::setValueNumber(double newvalue) {
  if (isReadOnly()) return;

  nulldata();
  flags.datatype = PDTNUMBER;
  value.number   = newvalue;
}

void prmBase::setValueGuid(GUID newvalue) {
  if (isReadOnly()) return;

  nulldata();
  value.guid     = newvalue;
  flags.datatype = PDTGUID;
}

void prmBase::setValueFourCC(FOURCC newvalue) {
  if (isReadOnly()) return;

  nulldata();
  value.fourcc   = newvalue;
  flags.datatype = PDTFOURCC;
}


void prmBase::nulldata() {
  if (flags.datatype == PDTSTRING) {
    free(value.string1);
  }
  ZeroMemory(&value, sizeof(value));
  flags.datatype = PDTNULL;
}


int prmBase::specialString(const char *string) {
  if (! string) return -2;
  if (!*string) return -2;

  if (VSTRCMPI(string, "1")        == 0) return  1;
  if (VSTRCMPI(string, "ok")       == 0) return  1;
  if (VSTRCMPI(string, "yes")      == 0) return  1;
  if (VSTRCMPI(string, "true")     == 0) return  1;
  if (VSTRCMPI(string, "enable")   == 0) return  1;
  if (VSTRCMPI(string, "enabled")  == 0) return  1;
  if (VSTRCMPI(string, "accept")   == 0) return  1;

  if (VSTRCMPI(string, "0")        == 0) return  0;
  if (VSTRCMPI(string, "nil")      == 0) return  0;
  if (VSTRCMPI(string, "null")     == 0) return  0;
  if (VSTRCMPI(string, "no")       == 0) return  0;
  if (VSTRCMPI(string, "false")    == 0) return  0;
  if (VSTRCMPI(string, "disable")  == 0) return  0;
  if (VSTRCMPI(string, "disabled") == 0) return  0;
  if (VSTRCMPI(string, "cancel")   == 0) return  0;

  if (VSTRCMPI(string, "-1")       == 0) return -1;
  if (VSTRCMPI(string, "toggle")   == 0) return -1;
  if (VSTRCMPI(string, "invert")   == 0) return -1;
  if (VSTRCMPI(string, "inverse")  == 0) return -1;
  if (VSTRCMPI(string, "not")      == 0) return -1;

  return -2;
}