/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#include "../rmxBase.h"
#include "cfgInt.h"


cfgInt::cfgInt(const char *initname, cfgBase *parent, cfgBase *insert, const char *unique)
  : cfgBase(initname, "int", parent, insert, unique) {
  setUserDataInt(0);
  insertParamIntNoSave("min",       0x80000000);
  insertParamIntNoSave("max",       0x7FFFFFFF);
  insertParamNoSave(   "style",     "edit");
}

cfgInt::~cfgInt() {
}

void cfgInt::onFirstLoad() {
  if (hasParam("default")) setValue(getDefault());
}

void cfgInt::setValue(int value, bool defaultval) {
  if (value == getValue()) return;
  if (value < getMin()) value = getMin();
  if (value > getMax()) value = getMax();
  setUserDataInt(value);
  if (defaultval) setDefault(value);
}


void cfgInt::setMin(int min) {
  if (min == getMin()) return;
  setParamInt("min", min);
}

void cfgInt::setMax(int max) {
  if (max == getMax()) return;
  setParamInt("max", max);
}

void cfgInt::setMinMax(int min, int max) {
  setMin(min);
  setMax(max);
}

int cfgInt::getMin() const {
  return getParamInt("min");
}

int cfgInt::getMax() const {
  return getParamInt("max");
}

void cfgInt::setDefault(int val) {
  if (hasParam("default")) setParamInt("default", val);
  else insertParamIntNoSave("default", val);
}

void cfgInt::validateUserData(prmBase *userdata) {
  if (!userdata->isInteger()) userdata->setValueInt( userdata->getValueInt() );
  if (userdata->getValueInt() < getMin()) userdata->setValueInt(getMin());
  if (userdata->getValueInt() > getMax()) userdata->setValueInt(getMax());
}


RMXLONG cfgInt::onMessage(HPLUGIN source, RMXLONG message, RMXLONG param1, RMXLONG param2) {
  if (message == GENERIC_GAIN_FOCUS) onGainFocus(source);
  if (message == GENERIC_LOST_FOCUS) onLostFocus(source);
  return cfgBase::onMessage(source, message, param1, param2);
}


void cfgInt::onSetParam(prmBase *param) {
  cfgBase::onSetParam(param);
  if (param->isNamed("min") || param->isNamed("max")) onSetMinMax();
}


