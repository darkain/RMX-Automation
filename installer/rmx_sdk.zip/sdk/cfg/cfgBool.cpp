/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#include "../rmxBase.h"
#include "cfgBool.h"


cfgBool::cfgBool(const char *initname, cfgBase *parent, cfgBase *insert, const char *unique)
 : cfgBase(initname, "bool", parent, insert, unique) {
  setUserDataInt(FALSE);
}


cfgBool::~cfgBool() {
}


void cfgBool::setValue(BOOL value, BOOL force) {
  value = !!value;
  if (force) {
    setUserDataInt(value);
  } else if (value != getValue()) {
    setUserDataInt(value);
  }
}


BOOL cfgBool::getValue() const {
  return getUserDataInt();
}


void cfgBool::validateUserData(prmBase *userdata) {
  userdata->setValueInt( !!userdata->getValueInt() );
}
