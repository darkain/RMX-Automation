/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


/***********************************************************************\
*   ALL class within any library that inherit from the cfgBase          *
*   class must strictly state their UserDate usage, as there is only    *
*   one user data per instance, and this is the primary peice of        *
*   information that will be passed around between object instances     *
*   and even application instances.                                     *
\***********************************************************************/


#ifndef _CFG_BASE_H_
#define _CFG_BASE_H_


#include "../rmxBase.h"
#include "../rmxList.h"
#include "../rmxName.h"
#include "../rmxTypes.h"
#include "../prm/prmBase.h"
#include "cfgMessage.h"


class cfgRoot;
class cbBase;


//this class will auto-save/load, but will NOT be shown in the configuration screen
//Note:  children automatically delete themselves when the parent is deleted
class cfgBase : public rmxName {
  friend class cfgRoot;
  friend class cbBase;

  public:
    cfgBase(const char *name, const char *vtype, cfgBase *listParent=NULL, cfgBase *insert=NULL, const char *unique=NULL);
    virtual ~cfgBase();

  public:


    //VVVVVVVVVVVVVVVVVVV//
    // basic list events //
    //^^^^^^^^^^^^^^^^^^^//

    //XML based events
    virtual void onFirstLoad();
    virtual void onPreSaveSettings();
    virtual void onSaveSettings();
    virtual void onPreLoadSettings();
    virtual void onLoadSettings();

    //data based events
    virtual void onNameChange(const char *newname);
    virtual void onSetTooltip(const char *newtip);
    virtual void onSetUserData(const prmBase *userdata);

    //param based events
    virtual void onInsertParam(const prmBase *param, const prmBase *insert);
    virtual void onRemoveParam(const prmBase *param);
    virtual void onSetParam(const prmBase *param);
    virtual void onMoveParam(const prmBase *param, const prmBase *insert);

    //child based events
    virtual void onInsertChild(cfgBase *child, const cfgBase *insert);
    virtual void onRemoveChild(const cfgBase* child);
    virtual void onMoveChild(const cfgBase *child, const cfgBase *insert);

    //we received a custom message
    virtual RMXLONG onMessage(HPLUGIN source, RMXLONG message, RMXLONG param1, RMXLONG param2) { return 0; }


    //this function is called when someone/thing tries to set UserData for our object
    //in here we can verify that the data being passed in is correct for what we need
    //example:  IntMax may be "5", you try to set UserData to "10", this could validate it to "5" and return "5"
    //example:  If we want only Int based data, and try to pass it "a", it could return NULL to prevent data from being changed
    //by default, what ever is passed in counts as valid and returns the same value.  orverride for your custom validation
    virtual void validateUserData(prmBase *userdata) {}

    //same as validateUserData, but for params instead
    virtual void validateParam(prmBase *param) {}


    //this function is called when the XML parser sees a child entity to your object that doesnt exist
    //this is a great way to create dynamically generated lists, but it is also a great way to break things
    //if you use this to create a new item... RETURN THE POINTER TO THE NEW ITEM!!!!
    //this is a 100% must so that way the internal XML system can keep track of whats going on
    //return NULL if you dont create any new objects
    virtual cfgBase *onNewExternalChild(const char *name, const char *type, const char *unique) { return NULL; }


    //similar to onNewExternalChild(), only this is called when there is an XML param we currently dont
    //have registered in our class.  by default, we do nothing.  if you add the param, return
    //a pointer to the new prmBase, just like how its done in onNewExternalChild()
    virtual prmBase *onNewExternalParam(const char *name, const char *value) { return NULL; }



    //VVVVVVVVVVVVVVVVVVVVVVVV//
    // basic list information //
    //^^^^^^^^^^^^^^^^^^^^^^^^//
//  const char *getName() const;    //handled by inheritance
    void setName(const char *name, BOOL cb=TRUE);
    inline const char *getType()    const { return type.getName();     }
    inline const char *getUnique()  const { return uniqueid.getName(); }
    inline const char *getTooltip() const { return tooltip.getName();  }
    void setTooltip(const char *tip);


    // setting userdata returns a validated version of userdata
    // example:  intMax may be "5", when try to set it to 10, it will set to 5 and return 5
    inline const char *getUserData()       const { return userdata.getValue(); }
    const char        *getUserDataSafe(const char *safe="") const;
    inline int         getUserDataInt()    const { return userdata.getValueInt(); }
    inline RMXLONG     getUserDataLong()   const { return userdata.getValueLong(); }
    inline double      getUserDataNumber() const { return userdata.getValueNumber(); }
    inline GUID        getUserDataGuid()   const { return userdata.getValueGuid(); }

    const char *setUserData(const char *newdata);
    const char *setUserDataString(const char *newdata);
    int         setUserDataInt(int newdata);
    RMXLONG     setUserDataLong(RMXLONG newdata);
    double      setUserDataNumber(double newdata);
    GUID        setUserDataGuid(GUID newdata);

    inline BOOL isUserDataString()  const { return userdata.isString();  }
    inline BOOL isUserDataInteger() const { return userdata.isInteger(); }
    inline BOOL isUserDataLong()    const { return userdata.isLong();    }
    inline BOOL isUserDataNumber()  const { return userdata.isNumber();  }
    inline BOOL isUserDataGuid()    const { return userdata.isGuid();    }



    //VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//
    // list properties and access rights //
    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^//

    // all flags for the config list
    inline UINT getFlags() const { return flags.flags; }

    // visible
    void setVisible(BOOL visible);
    inline BOOL isVisible() const { return flags.visible; }
    BOOL hasChildrenVisible(BOOL recursive=FALSE) const;
    virtual void onSetVisible(BOOL visible);

    // enabled
    void setEnabled(BOOL enabled);
    inline BOOL isEnabled() const { return flags.enabled; }
    BOOL hasChildrenEnabled(BOOL recursive=FALSE) const;
    virtual void onSetEnabled(BOOL enabled);

    // expanded
    void setExpanded(BOOL expanded);
    inline BOOL isExpanded() const { return flags.expanded; }
    BOOL hasChildrenExpanded(BOOL recursive=FALSE) const;
    virtual void onSetExpanded(BOOL expanded);

    // highlighted
    void setHighlighted(BOOL highlighted);
    inline BOOL isHighlighted() const { return flags.highlighted; }
    BOOL hasChildrenHighlighted(BOOL recursive=FALSE) const;
    virtual void onSetHighlighted(BOOL highlighted);

    // loadable/savable to XML
    void setSavable(BOOL savable);
    inline BOOL isSavable() const { return flags.savable; }
    BOOL hasChildrenSavable(BOOL recursive=FALSE) const;
    virtual void onSetSavable(BOOL savable);

    // accessable via TCP, RPC, NetSlave
    void setNetSlave(BOOL netslave);
    inline BOOL isNetSlave() const { return flags.netslave; }
    BOOL hasChildrenNetSlave(BOOL recursive=FALSE) const;
    virtual void onSetNetSlave(BOOL netslave);

    // accessable from other application, IPC
    void setIpc(BOOL ipc);
    inline BOOL isIpc() const { return flags.ipc; }
    BOOL hasChildrenIpc(BOOL recursive=FALSE) const;
    virtual void onSetIpc(BOOL ipc);

    // accessable from other application, IPC
    void setReadOnly(BOOL readonly);
    inline BOOL isReadOnly() const { return flags.readonly; }
    BOOL hasChildrenReadOnly(BOOL recursive=FALSE) const;
    virtual void onSetReadOnly(BOOL readonly);


    // all security access at once
    inline unsigned char getSecurity()   const { return flags.security; }
    inline unsigned char getSecurityEx() const { return flags.external; }




    //VVVVVVVVVVVVVVVV//
    // list paramater //
    //^^^^^^^^^^^^^^^^//

    // basic get/set param info
    const char *getParam(      const char *name) const;
    const char *getParamSafe(  const char *name, const char *safe="") const;
    int         getParamInt(   const char *name) const;
    RMXLONG     getParamLong(  const char *name) const;
    double      getParamNumber(const char *name) const;
    GUID        getParamGuid(  const char *name) const;

    void setParam(      const char *name, const char *value);
    void setParamString(const char *name, const char *value);
    void setParamInt(   const char *name, int         value);
    void setParamLong(  const char *name, RMXLONG     value);
    void setParamNumber(const char *name, double      value);
    void setParamGuid(  const char *name, GUID        value);
    inline void setParamNull(const char *name) { setParam(name, NULL); }

    // do we have a param?
    inline BOOL hasParam(const char *name) const { return !!getParamData(name);  }
    inline BOOL hasParam(prmBase *param)   const { return params.hasItem(param); }
    inline BOOL hasParams()                const { return params.hasItems();     }

    // add params to our list (NoSave = No XML Configuration load/saving for param)
    prmBase *insertParam(const char *name, const char *val=NULL, prmBase *insert=NULL);
    prmBase *insertParamInt(const char *name, int val, prmBase *insert=NULL);
    prmBase *insertParamNoSave(const char *name, const char *val=NULL, prmBase *insert=NULL);
    prmBase *insertParamIntNoSave(const char *name, int val, prmBase *insert=NULL);

    // what params do we have?
    inline BOOL canEnumerateParams()         const { return flags.queryparams;     }
    inline int getParamCount()               const { return params.getItemCount(); }
    inline prmBase *getFirstParam()          const { return params.getFirstItem(); }
    inline prmBase *getLastParam()           const { return params.getLastItem();  }
    inline prmBase *getPrevParam(prmBase *p) const { return params.getPrevItem(p); }
    inline prmBase *getNextParam(prmBase *p) const { return params.getNextItem(p); }
    prmBase *getParamData(const char *name)  const;

    // what are the param's flags?
    UINT getParamFlags(   const char *name) const;
    void setParamSavable( const char *name, BOOL savable);
    BOOL isParamSavable(  const char *name) const;
    void setParamReadOnly(const char *name, BOOL readonly);
    BOOL isParamReadOnly( const char *name) const;

    //remove a param
    void removeParam(prmBase *p);
    inline void removeParam(const char *name) { removeParam(getParamData(name)); }
    void removeAllParams();

    //move param
    void moveParam(const char         *param, const char         *insert);
    void moveParam(const prmBase *param, const prmBase *insert);



    //VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//
    //list hierarchy (parent info, child info, etc) //
    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^//

    // parent and root
    static cfgBase *getListRoot() { return rootlist; }
    inline cfgBase *getParent() const { return parent; }

    // children
    cfgBase *getChild(const char *name, const char *type="*", const char *unique=NULL) const;
    cfgBase *getChildById(RMXLONG id, BOOL recursive=FALSE) const;
    cfgBase *getChildByUserData(const char *data, BOOL recursive=FALSE) const;
    BOOL hasChild(cfgBase *list,  BOOL recursive=FALSE);
    BOOL hasChildCached(cfgBase *list);  //for internal use, automatically recursive
    inline BOOL hasChildren() const { return children.hasItems(); }
    inline int getChildCount() { return children.getItemCount(); }
    inline cfgBase *getFirstChild() { return children.getFirstItem(); }
    inline cfgBase *getLastChild()  { return children.getLastItem(); }
    inline cfgBase *getNextChild(cfgBase *item) { return children.getNextItem(item); }
    inline cfgBase *getPrevChild(cfgBase *item) { return children.getPrevItem(item); }

    //remove children
    void removeAllChildren();

    //move list position
    void moveListUp();
    void moveListDown();
    void moveListToBegining();
    void moveListToEnd();
    void moveChild(cfgBase *child, cfgBase *insert);



  //FOR INTERNAL USE ONLY
  //do not mess with any function after this point directly, unless you know what you are doing
  public:
    inline void setSecurityEx(unsigned char ex) { flags.external = ex; }
    inline HLIST getListHandle() const { return (HLIST) this; }

  private:
    prmBase *newParam(const char *name, prmBase *insert);

    void insertChild(cfgBase *child, cfgBase *insert=NULL);
    void removeChild(cfgBase *child);

    inline void setSecurity(unsigned char sec) { flags.security = sec; }

  public:
    inline void insertCallback(cbBase *cb) { callbacks.appendItem(cb); }
    inline void removeCallback(cbBase *cb) { callbacks.removeItem(cb); }


  private:
    typedef union {
      DWORD flags;
      struct {
        unsigned visible       :1;  //is this object visible to the GUI?
        unsigned enabled       :1;  //is this object enabled for user input?
        unsigned expanded      :1;  //is this object currently expanded to show children?
        unsigned highlighted   :1;  //is this object currently highlighted?
        unsigned expanded_ro   :1;  //is this object's expanded attrib locked from user input?
        unsigned queryparams   :1;  //can we enumerate params of this list?
        unsigned reserved0     :2;  //RESERVED
        unsigned reserved1     :8;  //RESERVED
        unsigned inheritdata   :8;  //data member available to classes that inherit this class
        unsigned savable       :1;  //is this object effected by XML saving and loading?
        unsigned ipc           :1;  //is this object accessable from IPC?  (Inter-Process Communication)
        unsigned netslave      :1;  //is this object accessable from NetSlave? (TCP/RPC layer for RMX)
        unsigned readonly      :1;  //is this object read only?
        unsigned external      :4;  //security data specific to RMX Core, auto-assigned, dont mess with it
      };
      struct {
        unsigned char settings;
        unsigned char reserved_ex[2];
        unsigned char security;
      };
    } FLAGS;

  private:
    FLAGS   flags;
    rmxName type;     //change to a new custom type, so that way things like "tree" dont need to malloc new RAM
    rmxName uniqueid;
    rmxName tooltip;

    prmBase userdata;

    cfgBase *parent;
    rmxList<cfgBase*> children;
    rmxList<prmBase*> params;
    rmxList<cbBase*>  callbacks;

  private:
    static cfgBase *rootlist;
};


#endif //_CFG_BASE_H_
