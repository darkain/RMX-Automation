/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#include "../rmxBase.h"
#include "cfgPath.h"


cfgPath::cfgPath(const char *name, cfgBase *par, cfgBase *insert, const char *unique)
 : cfgBase(name, "path", par, insert, unique) {

  insertParamNoSave("style", "");
}
