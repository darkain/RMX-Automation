/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#include "../rmxBase.h"
#include "cfgBase.h"
#include "cfgRoot.h"
#include "../cb/cbBase.h"


cfgBase *cfgBase::rootlist = NULL;


cfgBase::cfgBase(const char *name, const char *vtype, cfgBase *listParent, cfgBase *insert, const char *unique)
 : rmxName(name), type(vtype), uniqueid(unique) {

  //default flag values
  flags.flags       = 0;
  flags.visible     = TRUE;
  flags.enabled     = TRUE;
  flags.expanded    = FALSE;
  flags.highlighted = FALSE;
  flags.expanded_ro = FALSE;
  flags.queryparams = TRUE;

  //parent stuffz
  parent = listParent;
  if (!parent) parent = rootlist;
  if (parent) {
    flags.security = parent->getSecurity();
    parent->insertChild(this, insert);
  }
}


cfgBase::~cfgBase() {
  if (parent) {
    parent->removeChild(this);
  }

  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cb->cb_onDelete();
    callbacks.removeItem(cb);
    cb = callbacks.getFirstItem();
  }

  removeAllChildren();
  removeAllParams();
}



//////////////////////////////////////////////////////////////////////////////////////////////////


//VVVVVVVVVVVVVVVVVVV//
// basic list events //
//^^^^^^^^^^^^^^^^^^^//

//XML based events
void cfgBase::onFirstLoad() {
  cfgBase *child = children.getFirstItem();
  while (child) {
    cfgBase *next = children.getNextItem(child);
    child->onFirstLoad();
    child = next;
  }
}

void cfgBase::onPreSaveSettings() {
  cfgBase *child = children.getFirstItem();
  while (child) {
    cfgBase *next = children.getNextItem(child);
    child->onPreSaveSettings();
    child = next;
  }
}

void cfgBase::onSaveSettings() {
  cfgBase *child = children.getFirstItem();
  while (child) {
    cfgBase *next = children.getNextItem(child);
    child->onSaveSettings();
    child = next;
  }
}

void cfgBase::onPreLoadSettings() {
  cfgBase *child = children.getFirstItem();
  while (child) {
    cfgBase *next = children.getNextItem(child);
    child->onPreLoadSettings();
    child = next;
  }
}

void cfgBase::onLoadSettings() {
  cfgBase *child = children.getFirstItem();
  while (child) {
    cfgBase *next = children.getNextItem(child);
    child->onLoadSettings();
    child = next;
  }
}





//data based events
void cfgBase::onNameChange(const char *newname) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onNameChange(newname);
    cb = next;
  }
}

void cfgBase::onSetTooltip(const char *newtip) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetTooltip(newtip);
    cb = next;
  }
}

void cfgBase::onSetUserData(const prmBase *userdata) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetUserData(userdata);
    cb = next;
  }
}


//param based events
void cfgBase::onInsertParam(const prmBase *param, const prmBase *insert) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onInsertParam(param, insert);
    cb = next;
  }
}

void cfgBase::onRemoveParam(const prmBase *param) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onRemoveParam(param);
    cb = next;
  }
}

void cfgBase::onSetParam(const prmBase *param) {
  cbBase *cb = callbacks.getFirstItem();  //TODO:  copy the CB list instead, its safer
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetParam(param);
    cb = next;
  }
}


void cfgBase::onMoveParam(const prmBase *param, const prmBase *insert) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onMoveParam(param, insert);
    cb = next;
  }
}


//child based events
void cfgBase::onInsertChild(cfgBase *child, const cfgBase *insert) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onInsertChild(child, insert);
    cb = next;
  }
}

void cfgBase::onRemoveChild(const cfgBase* child) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onRemoveChild(child);
    cb = next;
  }
}

void cfgBase::onMoveChild(const cfgBase *child, const cfgBase *insert) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onMoveChild(child, insert);
    cb = next;
  }
}


//////////////////////////////////////////////////////////////////////////////////////////////////



//VVVVVVVVVVVVVVVVVVVVVVVV//
// basic list information //
//^^^^^^^^^^^^^^^^^^^^^^^^//

void cfgBase::setName(const char *name, BOOL cb) {
  if (isReadOnly()) return;
  rmxName::setName(name, cb);
}


void cfgBase::setTooltip(const char *tip) {
  if (isReadOnly()) return;
  tooltip.setName(tip);
  onSetTooltip(tip);
}


const char *cfgBase::getUserDataSafe(const char *safe) const {
  const char *ret = userdata.getValue();
  if (!ret) return safe;
  return ret;
}


const char *cfgBase::setUserData(const char *newdata) {
  if (isReadOnly()) return NULL;
  userdata.setValue(newdata);
  validateUserData(&userdata);
  onSetUserData(&userdata);
  return userdata.getValue();
}


const char *cfgBase::setUserDataString(const char *newdata) {
  if (isReadOnly()) return NULL;
  userdata.setValueString(newdata);
  validateUserData(&userdata);
  onSetUserData(&userdata);
  return userdata.getValue();
}


int cfgBase::setUserDataInt(int newdata) {
  if (isReadOnly()) return 0;
  userdata.setValueInt(newdata);
  validateUserData(&userdata);
  onSetUserData(&userdata);
  return userdata.getValueInt();
}


RMXLONG cfgBase::setUserDataLong(RMXLONG newdata) {
  if (isReadOnly()) return 0;
  userdata.setValueLong(newdata);
  validateUserData(&userdata);
  onSetUserData(&userdata);
  return userdata.getValueLong();
}


double cfgBase::setUserDataNumber(double newdata) {
  if (isReadOnly()) return 0;
  userdata.setValueNumber(newdata);
  validateUserData(&userdata);
  onSetUserData(&userdata);
  return userdata.getValueNumber();
}


GUID cfgBase::setUserDataGuid(GUID newdata) {
  if (isReadOnly()) return _INVALID_GUID;
  userdata.setValueGuid(newdata);
  validateUserData(&userdata);
  onSetUserData(&userdata);
  return userdata.getValueGuid();
}


//////////////////////////////////////////////////////////////////////////////////////////////////


//VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//
// list properties and access rights //
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^//

//visible
void cfgBase::setVisible(BOOL visible) {
  if (isReadOnly()) return;
  visible = !!visible;
  if (flags.visible == (unsigned)visible) return;
  flags.visible = visible;
  onSetVisible(visible);
}

BOOL cfgBase::hasChildrenVisible(BOOL recursive) const {
  cfgBase *list = children.getFirstItem();
  while (list) {
    if (list->isVisible() == TRUE) return TRUE;
    if (recursive) {
      if (list->hasChildrenVisible(TRUE)) return TRUE;
    }
    list = children.getNextItem(list);
  }
  return FALSE;
}

void cfgBase::onSetVisible(BOOL visible) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetVisible(visible);
    cb = next;
  }
}


//enabled
void cfgBase::setEnabled(BOOL enabled) {
  if (isReadOnly()) return;
  enabled = !!enabled;
  if (flags.enabled == (unsigned)enabled) return;
  flags.enabled = enabled;
  onSetEnabled(enabled);
}

BOOL cfgBase::hasChildrenEnabled(BOOL recursive) const {
  cfgBase *list = children.getFirstItem();
  while (list) {
    if (list->isEnabled() == TRUE) return TRUE;
    if (recursive) {
      if (list->hasChildrenEnabled(TRUE)) return TRUE;
    }
    list = children.getNextItem(list);
  }
  return FALSE;
}

void cfgBase::onSetEnabled(BOOL enabled) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetEnabled(enabled);
    cb = next;
  }
}


//expanded
void cfgBase::setExpanded(BOOL expanded) {
  if (isReadOnly()) return;
  expanded = !!expanded;
  if (flags.expanded == (unsigned)expanded) return;
  flags.expanded = expanded;
  onSetExpanded(expanded);
}

BOOL cfgBase::hasChildrenExpanded(BOOL recursive) const {
  cfgBase *list = children.getFirstItem();
  while (list) {
    if (list->isExpanded() == TRUE) return TRUE;
    if (recursive) {
      if (list->hasChildrenExpanded(TRUE)) return TRUE;
    }
    list = children.getNextItem(list);
  }
  return FALSE;
}

void cfgBase::onSetExpanded(BOOL expanded) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetExpanded(expanded);
    cb = next;
  }
}


//highlighted
void cfgBase::setHighlighted(BOOL highlighted) {
  if (isReadOnly()) return;
  highlighted = !!highlighted;
  if (flags.highlighted == (unsigned)highlighted) return;
  flags.highlighted = highlighted;
  onSetHighlighted(highlighted);
}

BOOL cfgBase::hasChildrenHighlighted(BOOL recursive) const {
  cfgBase *list = children.getFirstItem();
  while (list) {
    if (list->isHighlighted() == TRUE) return TRUE;
    if (recursive) {
      if (list->hasChildrenHighlighted(TRUE)) return TRUE;
    }
    list = children.getNextItem(list);
  }
  return FALSE;
}

void cfgBase::onSetHighlighted(BOOL highlighted) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetHighlighted(highlighted);
    cb = next;
  }
}


//loadable/savable to XML
void cfgBase::setSavable(BOOL savable) {
  if (isReadOnly()) return;
  savable = !!savable;
  if (flags.savable == (unsigned)savable) return;
  flags.savable = savable;
  onSetSavable(savable);
}

BOOL cfgBase::hasChildrenSavable(BOOL recursive) const {
  cfgBase *list = children.getFirstItem();
  while (list) {
    if (list->isSavable() == TRUE) return TRUE;
    if (recursive) {
      if (list->hasChildrenSavable(TRUE)) return TRUE;
    }
    list = children.getNextItem(list);
  }
  return FALSE;
}

void cfgBase::onSetSavable(BOOL savable) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetSavable(savable);
    cb = next;
  }
}


//accessable via TCP, RPC, NetSlave
void cfgBase::setNetSlave(BOOL netslave) {
  if (isReadOnly()) return;
  netslave = !!netslave;
  if (flags.netslave == (unsigned)netslave) return;
  flags.netslave = netslave;
  onSetNetSlave(netslave);
}

BOOL cfgBase::hasChildrenNetSlave(BOOL recursive) const {
  cfgBase *list = children.getFirstItem();
  while (list) {
    if (list->isNetSlave() == TRUE) return TRUE;
    if (recursive) {
      if (list->hasChildrenNetSlave(TRUE)) return TRUE;
    }
    list = children.getNextItem(list);
  }
  return FALSE;
}

void cfgBase::onSetNetSlave(BOOL netslave) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetNetSlave(netslave);
    cb = next;
  }
}


//accessable from other application, IPC
void cfgBase::setIpc(BOOL ipc) {
  if (isReadOnly()) return;
  ipc = !!ipc;
  if (flags.ipc == (unsigned)ipc) return;
  flags.ipc = ipc;
  onSetIpc(ipc);
}

BOOL cfgBase::hasChildrenIpc(BOOL recursive) const {
  cfgBase *list = children.getFirstItem();
  while (list) {
    if (list->isIpc() == TRUE) return TRUE;
    if (recursive) {
      if (list->hasChildrenIpc(TRUE)) return TRUE;
    }
    list = children.getNextItem(list);
  }
  return FALSE;
}

void cfgBase::onSetIpc(BOOL ipc) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetIpc(ipc);
    cb = next;
  }
}


//read only from everything?
void cfgBase::setReadOnly(BOOL readonly) {
  readonly = !!readonly;
  if (flags.readonly == (unsigned)readonly) return;
  flags.readonly = readonly;
  onSetReadOnly(readonly);
}

BOOL cfgBase::hasChildrenReadOnly(BOOL recursive) const {
  cfgBase *list = children.getFirstItem();
  while (list) {
    if (list->isReadOnly() == TRUE) return TRUE;
    if (recursive) {
      if (list->hasChildrenReadOnly(TRUE)) return TRUE;
    }
    list = children.getNextItem(list);
  }
  return FALSE;
}

void cfgBase::onSetReadOnly(BOOL readonly) {
  cbBase *cb = callbacks.getFirstItem();
  while (cb) {
    cbBase *next = callbacks.getNextItem(cb);
    cb->cb_onSetReadOnly(readonly);
    cb = next;
  }
}


//////////////////////////////////////////////////////////////////////////////////////////////////


//VVVVVVVVVVVVVVVV//
// list paramater //
//^^^^^^^^^^^^^^^^//

// basic get/set param info
const char *cfgBase::getParam(const char *name) const {
  prmBase *param = getParamData(name);
  if (!param) return NULL;
  return param->getValue();
}

const char *cfgBase::getParamSafe(const char *name, const char *safe) const {
  prmBase *param = getParamData(name);
  if (!param) return safe;
  const char *value = param->getValue();
  if (!value) return safe;
  return value;
}

int cfgBase::getParamInt(const char *name) const {
  prmBase *param = getParamData(name);
  if (!param) return 0;
  return param->getValueInt();
}

RMXLONG cfgBase::getParamLong(const char *name) const {
  prmBase *param = getParamData(name);
  if (!param) return 0;
  return param->getValueLong();
}

double cfgBase::getParamNumber(const char *name) const {
  prmBase *param = getParamData(name);
  if (!param) return 0;
  return param->getValueNumber();
}

GUID cfgBase::getParamGuid(const char *name) const {
  prmBase *param = getParamData(name);
  if (!param) return _INVALID_GUID;
  return param->getValueGuid();
}


void cfgBase::setParam(const char *name, const char *value) {
  if (isReadOnly()) return;
  prmBase *param = getParamData(name);
  if (!param) return;
  param->setValue(value);
  onSetParam(param);
}

void cfgBase::setParamString(const char *name, const char *value) {
  if (isReadOnly()) return;
  prmBase *param = getParamData(name);
  if (!param) return;
  param->setValueString(value);
  onSetParam(param);
}

void cfgBase::setParamInt(const char *name, int value) {
  if (isReadOnly()) return;
  prmBase *param = getParamData(name);
  if (!param) return;
  param->setValueInt(value);
  onSetParam(param);
}

void cfgBase::setParamLong(const char *name, RMXLONG value) {
  if (isReadOnly()) return;
  prmBase *param = getParamData(name);
  if (!param) return;
  param->setValueLong(value);
  onSetParam(param);
}

void cfgBase::setParamNumber(const char *name, double value) {
  if (isReadOnly()) return;
  prmBase *param = getParamData(name);
  if (!param) return;
  param->setValueNumber(value);
  onSetParam(param);
}

void cfgBase::setParamGuid(const char *name, GUID value) {
  if (isReadOnly()) return;
  prmBase *param = getParamData(name);
  if (!param) return;
  param->setValueGuid(value);
  onSetParam(param);
}



//add params to our list (NoSave = No XML Configuration loading/saving for param)
prmBase *cfgBase::insertParam(const char *name, const char *val, prmBase *insert) {
  if (isReadOnly()) return NULL;
  prmBase *param = newParam(name, insert);
  if (!param) return NULL;
  param->setValueString(val);
  onInsertParam(param, insert);
  return param;
}


prmBase *cfgBase::insertParamInt(const char *name, int val, prmBase *insert) {
  if (isReadOnly()) return NULL;
  prmBase *param = newParam(name, insert);
  if (!param) return NULL;
  param->setValueInt(val);
  onInsertParam(param, insert);
  return param;
}


prmBase *cfgBase::insertParamNoSave(const char *name, const char *val, prmBase *insert) {
  if (isReadOnly()) return NULL;
  prmBase *param = insertParam(name, val, insert);
  if (param) param->flags.savable = FALSE;
  return param;
}


prmBase *cfgBase::insertParamIntNoSave(const char *name, int val, prmBase *insert) {
  if (isReadOnly()) return NULL;
  prmBase *param = insertParamInt(name, val, insert);
  if (param) param->flags.savable = FALSE;
  return param;
}


//what params do we have?
prmBase *cfgBase::getParamData(const char *name) const {
  prmBase *param = params.getCachedItem();
  if (param) if (param->isNamed(name)) return param;

  param = params.getFirstItem();
  while (param) {
    if (param->isNamed(name)) return param;
    param = params.getNextItem(param);
  }
  return NULL;
}



//what are the param's flags?
UINT cfgBase::getParamFlags(const char *name) const {
  prmBase *param = getParamData(name);
  if (param) return param->flags.flags;
  return 0;
}


void cfgBase::setParamSavable(const char *name, BOOL savable) {
  if (isReadOnly()) return;
  prmBase *param = getParamData(name);
  if (param) param->setSavable(savable);
}

BOOL cfgBase::isParamSavable(const char *name) const {
  prmBase *param = getParamData(name);
  return (param) ? (param->isSavable()) : (FALSE);
}

void cfgBase::setParamReadOnly(const char *name, BOOL readonly) {
  if (isReadOnly()) return;
  prmBase *param = getParamData(name);
  if (param) param->setReadOnly(readonly);
}

BOOL cfgBase::isParamReadOnly(const char *name) const {
  prmBase *param = getParamData(name);
  return (param) ? (param->isReadOnly()) : (FALSE);
}


//remove a param
void cfgBase::removeParam(prmBase *p) {
  if (isReadOnly()) return;
  if (!p) return;
  if (!params.hasItem(p)) return;
  params.removeItem(p);
  onRemoveParam(p);
  delete p;
}


void cfgBase::removeAllParams() {
  if (isReadOnly()) return;
  prmBase *p = params.getFirstItem();
  while (p) {
    params.removeItem(p);
    onRemoveParam(p);
    delete p;
    p = params.getFirstItem();
  }
}


//move param
void cfgBase::moveParam(const char *param, const char *insert) {
  moveParam(getParamData(param), getParamData(insert));
}

void cfgBase::moveParam(const prmBase *param, const prmBase *insert) {
  if (isReadOnly()  ||  !param) return;
  params.moveItem((prmBase*)param, (prmBase*)insert);
  onMoveParam(param, insert);
}





//////////////////////////////////////////////////////////////////////////////////////////////////

//VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//
//list hierarchy (parent info, child info, etc) //
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^//
cfgBase *cfgBase::getChild(const char *name, const char *type, const char *unique) const {
  if (name==NULL || *name==NULL) return NULL;

  BOOL allTypes = FALSE;
  if (type == NULL) {
    allTypes = TRUE;
  } else if (*type == NULL) {
    allTypes = TRUE;
  } else if (VSTRCMP("*", type) == 0) {
    allTypes = TRUE;
  }

  cfgBase *list = children.getFirstItem();
  while (list) {
    if (VSTRCMP(list->getName(""), name) == 0) {
      if (allTypes) {
        if (unique == NULL) {
          return list;
        } else if (list->getUnique() != NULL) {
          if (VSTRCMP(unique, list->getUnique()) == 0) return list;
        }
      }
      else if (VSTRCMP(list->getType(), type) == 0) {
        if (unique == NULL) {
          return list;
        } else if (list->getUnique() != NULL) {
          if (VSTRCMP(unique, list->getUnique()) == 0) return list;
        }
      }
    }
    list = children.getNextItem(list);
  }
  return NULL;
}


cfgBase *cfgBase::getChildById(RMXLONG id, BOOL recursive) const {
  cfgBase *child = children.getFirstItem();
  while (child) {
    if (child->getParamLong("id") == id) return child;
    if (recursive) {
      cfgBase *item = child->getChildById(id, recursive);
      if (item) return item;
    }
    child = children.getNextItem(child);
  }
  return NULL;
}


//todo: add this to core api
cfgBase *cfgBase::getChildByUserData(const char *data, BOOL recursive) const {
  if (!data) return NULL;
  
  cfgBase *child = children.getFirstItem();
  while (child) {
    const char *userdata = child->getUserData();
    if (userdata  &&  VSTRCMP(userdata, data)==0) return child;
    if (recursive) {
      cfgBase *item = child->getChildByUserData(data, recursive);
      if (item) return item;
    }
    child = children.getNextItem(child);
  }

  return NULL;
}


BOOL cfgBase::hasChild(cfgBase *list, BOOL recursive) {
  if (!list)      return FALSE;
  if (!recursive) return children.hasItem(list);
  if (children.getCachedItem() == list) return TRUE;

  cfgBase *child = children.getFirstItem();
  while (child) {
    if (child == list) return TRUE;
    if (child->hasChild(list, recursive)) return TRUE;
    child = children.getNextItem(child);
  }
  return FALSE;
}


//similar to hasChild, but only checks item cache, and is always recursive
BOOL cfgBase::hasChildCached(cfgBase *list) {
  cfgBase *child = children.getCachedItem();
  if (child) {
    if (child == list) return TRUE;
    if (child->hasChildCached(list)) return TRUE;
  }
  return FALSE;
}


//remove children
void cfgBase::removeAllChildren() {
  if (isReadOnly()) return;
  cfgBase *child = children.getFirstItem();
  while (child) {
    delete child;  //deleting the child will automatically run callbacks
    children.removeItem(child);
    child = children.getFirstItem();
  }
}


void cfgBase::moveListUp() {
  if (isReadOnly()) return;
  cfgBase *parent = getParent();
  if (!parent) return;
  cfgBase *prev = parent->getPrevChild(this);
  if (prev) parent->moveChild(this, prev);
}


void cfgBase::moveListDown() {
  if (isReadOnly()) return;
  cfgBase *parent = getParent();
  if (!parent) return;
  cfgBase *next = parent->getNextChild(parent->getNextChild(this));
  parent->moveChild(this, next);
}


void cfgBase::moveListToBegining() {
  if (isReadOnly()) return;
  cfgBase *parent = getParent();
  if (!parent) return;
  cfgBase *first = parent->getFirstChild();
  if (first) parent->moveChild(this, first);
}


void cfgBase::moveListToEnd() {
  if (isReadOnly()) return;
  cfgBase *parent = getParent();
  if (!parent) return;
  parent->moveChild(this, NULL);
}


void cfgBase::moveChild(cfgBase *child, cfgBase *insert) {
  if (isReadOnly()) return;
  children.moveItem(child, insert);
  onMoveChild(child, insert);
}



//////////////////////////////////////////////////////////////////////////////////////////////////



prmBase *cfgBase::newParam(const char *name, prmBase *insert) {
  if (!name) return NULL;
  if (!*name) return NULL;

#ifdef _DEBUG
  if (getParamData(name)) {
    char str[1024];
    VPRINTF(str, sizeof(str), "insertParam() > Param Already Exists!  [%s]", name);
    CONSOLE_MAIN->print(str);
    return NULL;
  }
#endif//_DEBUG

  prmBase *param = new prmBase(name);
  param->setSecurity(getSecurity() & 0x0F);
  params.insertItem(param, insert);
  return param;
}


void cfgBase::insertChild(cfgBase *child, cfgBase *insert) {
  if (!child) return;
  children.insertItem(child, insert);
  onInsertChild(child, insert);
}


void cfgBase::removeChild(cfgBase *child) {
  if (!children.hasItem(child)) return;
  children.removeItem(child);
  onRemoveChild(child);
}
