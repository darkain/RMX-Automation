/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#include "../rmxBase.h"
#include "cfgRoot.h"


cfgRoot::cfgRoot(const char *name) : cfgBase(name, "root") {


#ifdef _DEBUG
#ifdef RMX_PLUGIN
  if (rootlist != NULL) {
    CONSOLE_MAIN->printError("SERIOUS FUCKING ERROR", "Multiple instances of class cfgRoot");
  }
#endif //RMX_PLUGIN
#endif //_DEBUG

  rootlist = this;

  //initial default config for the root list
  setSavable(TRUE);
  setIpc(TRUE);
  setNetSlave(TRUE);
  setReadOnly(FALSE);

  insertParamInt("id", -1);

  id = new cfgBase("Identification", "info");
  id->insertParamInt("lib", _SDK_BUILD);  //version of RMX LIB (lib will overwrite this value)
  id->insertParamInt("sdk", _SDK_BUILD);  //version of RMX SDK
}


cfgRoot::~cfgRoot() {
  rootlist = NULL;
}



void cfgRoot::onPreLoadSettings() {
  id->setSavable(FALSE);
  cfgBase::onPreLoadSettings();
}


void cfgRoot::onLoadSettings() {
  cfgBase::onLoadSettings();
  id->setSavable(TRUE);
}
