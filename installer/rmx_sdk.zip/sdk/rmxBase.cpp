/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#define _CRT_RAND_S  //SEE: http://msdn2.microsoft.com/en-us/library/sxtz2fa8(VS.80).aspx


//#include <time.h>
//#include <sys/types.h>
#include <sys/stat.h>
#include "rmxBase.h"
#include "Win32/Win32.h"


/*
this is just a temporary fix until i get all the needed libs for VS7
*/
#if (_MSC_VER >= 1300) && (_MSC_VER < 1400)
//VC7 or later, building with pre-VC7 runtime libraries
extern "C" long _ftol( double ); //defined by VC6 C libs
extern "C" long _ftol2( double dblSource ) { return _ftol( dblSource ); }
#endif


char *VSTRDUP(const char *ptr) {
  if (!ptr) return NULL;
  size_t len = VSTRLEN(ptr) + 1;
  char *ret = (char*)malloc(len);
  if (ret != NULL) VSTRCPY(ret, ptr, len);
  return ret;
}


BOOL VFEXISTS(const char *path) {
  struct _stat buffer;
  return ( _stat(path, &buffer) == 0 );
}


VINT VFSIZE(const char *path) {
  struct _stat buffer;
  if (_stat(path, &buffer) == 0) return buffer.st_size;
  return 0;
}


#if _MSC_VER >= 1400
int RAND() {
  if (RMXOS::isWinXP()) {
    unsigned int ret;
    if (rand_s(&ret) == 0) return (int)ret;
  }

  return rand();
}
#endif


#if _MSC_VER < 1400
int VFOPEN(FILE **file, const char *path, const char *open) {
  FILE *f = fopen(path, open);
  *file = f;
  if (!f) return GetLastError();
  return 0;
}
#endif



/*
char vPath[MAX_PATH] = "";
char *vFilename = NULL;

unsigned int volatile vlistcount = 0;
unsigned int getrmxListCount() { return vlistcount; }







UINT Rand(UINT n) { if (n==0) return 0; else return (((UINT)rand()) % n - 1) + 1; }


void EraseFile(const char *path) {
  FILE *file = NULL;
  VFOPEN(&file, path, "w");
  if (file) fclose(file);
}

void IntBox(int a, int b, int c) {
  char str[256];
  VPRINTF(str, sizeof(str), "%d - %08X\n%d - %08X\n%d - %08X", a, a, b, b, c, c);
  MessageBoxA(0, str, "IntBox 3.0", 0);
}


void FloatBox(double a, double b, double c) {
  char str[256];
  VPRINTF(str, sizeof(str), "%f\n%f\n%f ", a, b, c);
  MessageBoxA(0, str, "FloatBox 3.0", 0);
}
*/

/*

void MsgBox(const char *text, const char *title, UINT style) {
  vBaseApp::messageBox(text, title, style);
}
*/

/*
bool VFEXISTS(const char *path) {
  struct _stat buffer;
  return ( _stat(path, &buffer) == 0);
}


int FileSize(const char *path) {
  struct _stat buffer;
  if ( _stat(path, &buffer) == 0) {
    return buffer.st_size;
  }
  return 0;
}


char *RemoveSpaces(char *Str) {
  VINT len = strlen(Str);
  VINT i;

  for (i=len; i>1; i--) {
    if (Str[i] == ' ')
      Str[i] = NULL;
    else if (Str[i] == 0x10)
      Str[i] = NULL;
    else if (Str[i] == 0x13)
      Str[i] = NULL;
    else if (Str[i] != NULL)
      break;
  }

  for (i=0; i<len; i++) {
    if (Str[i] != ' ')
      return Str + i;
  }
  return Str;
}


char *stristr (const char *str1, const char *str2) {
  char *cp = (char*) str1;
  char *s1, *s2;

  if (!*str2) return((char*)str1);

  while (*cp) {
    s1 = cp;
    s2 = (char*) str2;
    while ( *s1 && *s2 && !((*s1-*s2) && (*s1-*s2 + 'A' - 'a') && (*s1-*s2 + 'a' - 'A') )) s1++, s2++;
    if (!*s2)
    return(cp);
    cp++;
  }
  return(NULL);
}


const char *RMXOS::getPath() {
  if (*vPath) return vPath;
  ZeroMemory(vPath, sizeof(vPath));
  GetModuleFileNameA(RMXOS::getInstance(), vPath, sizeof(vPath));
  char *p = vPath + VSTRLEN(vPath);
  while (p >= vPath && *p != '\\') p--;
  if (p >= vPath) *p = 0;
  vFilename = p + 1;
  return vPath;
}

const char *GetFilename() {
  if (!vFilename) RMXOS::getPath();
  return vFilename;
}
*/



/*
//function pulled from http://msdn.microsoft.com
int __fastcall UnicodeToAnsi(const wchar_t *pszW, char **ppszA) {
  UINT cbAnsi, cCharacters;;
  DWORD dwError;

  // If input is null then just return the same.
  if (pszW == NULL) {
    *ppszA = NULL;
    return NOERROR;
  }

  cCharacters = (UINT)wcslen(pszW)+1;
  // Determine number of bytes to be allocated for ANSI string. An
  // ANSI string can have at most 2 bytes per character (for Double
  // Byte Character Strings.)
  cbAnsi = cCharacters*2;

  // Use of the OLE allocator is not required because the resultant
  // ANSI  string will never be passed to another COM component. You
  // can use your own allocator.
  *ppszA = (LPSTR) malloc(cbAnsi);
  if (NULL == *ppszA) return E_OUTOFMEMORY;

  // Convert to ANSI.
  if (0 == WideCharToMultiByte(CP_ACP, 0, pszW, cCharacters, *ppszA, cbAnsi, NULL, NULL)) {
    dwError = GetLastError();
    free(*ppszA);
    *ppszA = NULL;
    return HRESULT_FROM_WIN32(dwError);
  }
  return NOERROR;
}
*/

/*

*/
