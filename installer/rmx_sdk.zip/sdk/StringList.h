/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


#ifndef __STRINGLIST_H_
#define __STRINGLIST_H_


#include "rmxList.h"
#include "rmxPair.h"


#define vNullStringList vNullAnsiStringList


class vNullAnsiStringList : public rmxList<const char*> {
  public:
    vNullAnsiStringList(const char *buffer) {
      if (!buffer) return;
      appendItem(buffer);
      while (*buffer) {
        buffer++;
        if (*buffer == 0) {
          buffer++;
          if (*buffer) appendItem(buffer);
        }
      }
    }
};


class vNullUnicodeStringList : public rmxList<const short*> {
  public:
    vNullUnicodeStringList(const short *buffer) {
      if (!buffer) return;
      appendItem(buffer);
      while (*buffer) {
        buffer++;
        if (*buffer == 0) {
          buffer++;
          if (*buffer) appendItem(buffer);
        }
      }
    }
};



template <class T>
class vNullStringPairList : public rmxDeleteList<rmxPair<T>*> {
  public:
    vNullStringPairList(T *buffer) {
      for (int i=0; buffer[i]; i+=2) {
        appendItem(new rmxPair<T>(buffer[i], buffer[i+1]));
      }
    }

    ~vNullStringPairList() {
      emptyItems();
    }

  public:
    T getItemValue(T n) {
      rmxPair<T> *p = getFirstItem();
      while (p) {
        if (VSTRCMP(n, p->one) == 0) return p->two;
        p = getNextItem(p);
      }
      return NULL;
    }
};


#endif//__STRINGLIST_H_
