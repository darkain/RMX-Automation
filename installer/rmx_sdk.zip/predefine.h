/******************************  RMX SDK  ******************************\
*  Copyright (c) 2007 Vincent E. Milum Jr., All rights reserved.        *
*                                                                       *
*  See license.txt for more information                                 *
*                                                                       *
*  Latest SDK versions can be found at:  http://rmx.sourceforge.net     *
\***********************************************************************/


/*
* This file contains all of the basic configuration information used
* by ALL RMX related projects.  This includes things such as turning
* on/off DirectX support.
*/


#ifndef _RMX_PREDEFINES_
#define _RMX_PREDEFINES_


#define _SDK_BUILD     20070101
#define _SDK_VERSION  "20070101"
#define _RMX_BUILD     1.4
#define _RMX_VERSION  "1.4"
#define _APP_VERSION  "v" _RMX_VERSION " (" _SDK_VERSION ")"
#define _APP_INFO      1,4,0,0
//#define _BETA



/* ONLY ONE OF THESE SHOULD BE ACTIVE AT A TIME */
//#define RMX_MEDIAEDITION
//#define RMX_STANDALONE
//#define RMX_GAMINGEDITION
//#define RMX_PLUGIN



#ifdef _DEBUG
#  define RMX_DEBUG
#else
//#  define RMX_DEBUG
#endif

#define RMX_PLUGINLOADER
//#define RMX_IPCLOADER  //currently b0rkt



//todo: change these
#define LUA_SCRIPTING
#define USE_DIRECTX


#ifdef RMX_DEBUG
#  define DEBUGMSG(name, msg) CONSOLE_MAIN->printDebug(name, msg)
#  define PROFILE()      { char str[256]=""; VPRINTF(str, sizeof(str), "%d : %s %d",      RMXOS::getTick(), __FILE__, __LINE__);     DEBUGMSG("Profile", str); }
#  define PROFILE_STR(x) { char str[256]=""; VPRINTF(str, sizeof(str), "%d : %s %d : %s", RMXOS::getTick(), __FILE__, __LINE__, x);  DEBUGMSG("Profile", str); }
#  define PROFILE_INT(x) { char str[256]=""; VPRINTF(str, sizeof(str), "%d : %s %d : %d", RMXOS::getTick(), __FILE__, __LINE__, x);  DEBUGMSG("Profile", str); }
#else
#  define DEBUGMSG(name, msg)
#  define PROFILE()
#  define PROFILE_STR(x)
#  define PROFILE_INT(x)
#endif


#ifdef RMX_MEDIAEDITION
#  define RMX_WINAMP
#  define RMX_WMP
#  define RMX_RADLIGHT
#  define RMX_BSP
#  if (_MSC_VER > 1200)      //the foobar2000 SDK will not compile on Visual Studio 6
#    define RMX_FOOBAR2000
#  endif
#endif


#endif //_RMX_PREDEFINES_
